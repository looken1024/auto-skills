#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""微头条脚本化生成：选题（小上下文 LLM）→ 写稿（小上下文 LLM）→ 落盘。

每次模型调用都是独立小请求（2-6k 字符），不走 agent 长会话，绕开免费池的输入 token 限流。
用法：
  python3 wt_generate.py                 # 从 /tmp/wt_hot.json 选题目并写稿
  python3 wt_generate.py --topic "xxx"   # 指定题目直接写稿
输出：/tmp/wt_topic.json + /tmp/wt_draft.txt（stdout 打印两者）
"""
import argparse
import json
import os
import re
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from wt_common import llm, load_ledger_titles, load_ledger_recent_text  # noqa: E402

STYLE = """写作硬要求（今日头条微头条，账号「棱镜折射」）：
- 400-500 字，中文，一段一句话为主，短句，口语化，读起来像人在说话
- 一篇只讲一个核心观点，不要面面俱到
- 有情绪、可以带一点反讽，可以有方言口吻（比如"咱""啥""咋"），但不要油腻
- 数字要具体（金额、天数、比例、时间都写清楚）
- 【数据迭代 2026-09-14 · 硬性】首句必须是「具体事件+数字/金额/人物/已发生动作」，禁止以"很多人觉得/大家/说实话/最近"等泛群体视角开头。实测（后台真实展现数据）：故事型首句展现 813-1659，泛议题首句只有 26-86。写完自检首句：不含具体数字/人物/事件 → 重写开头
- 结尾抛一个问题，或给一条能马上用的建议
- 严禁 AI 惯用语："近日""随着…""值得注意的是""这一事件""不难看出""总而言之""本质上"
- 严禁网感梗句："离谱在哪""谁懂啊""绝了""破防了""CPU 烧了"
- 不要 markdown 标记、不要小标题、不要列表、不要 emoji，纯自然段
- 直接输出正文，不要写"标题："、不要解释、不要加引号包裹整篇

## 去AI味自查（lieflat-less-ai-tone，写完逐条检查）
写完后自己逐句过一遍，命中以下任一就改掉再输出：

1. 翻案腔：不要写"不是……而是""并非……而是""不在于……而在于""与其说……不如说""表面……实际……""看似……实则""不是A是B""你以为……其实……""回头才发现""说到底""答案恰恰相反""A不重要重要的是B"。先立误解再推翻是 AI 腔，直接正面下判断。
2. 顿号罗列过密：一句内不要用两个以上顿号连起三项以上并列。能概括就概括，必须保留三项时改变其中一项的句法。
3. 相邻句结构同款：连续2-3句不要用同一个句法骨架、同样的逗号位置。写完自查有没有"读着像在填表"的感觉。
4. 破折号：不要用破折号做揭晓（"答案其实很简单——专注。"）。直接写完整句子。
5. 冒号：不要用"一句话总结："或"我见过的几种典型场景："这种提示语+冒号。直接写内容。
6. 序数词当小标题：微头条没有小标题，这条不适用。
7. 拟人化喻体：不要写"像一位智慧的导师""一个永不疲倦的审查员"这类。具体的人当喻体可以（"像一个老师傅"）。
8. 抽象概括盖掉具体数据：不要写"效率的提升""大幅增长"而同段已有具体数字。有数字就直接用数字。
9. 禁用起手式：不要写"说白了""说穿了""先说结论"。
10. 翻译腔（只五种）：①中心词前修饰成分超过15字或"的"字连续两个以上 ②"当……时"开头的前置时间从句 ③"对于……来说""关于……"这类前置话题壳 ④句首"然而""因此""此外" ⑤"这意味着""这表明"式复述句。五种之外的生硬表达不要改。
11. 段首零主语评论：非首段不要以"听起来""值得注意的是""更重要的是""关键在于"开头且没有"这/那/其/此"回指成分。

不作为改写理由（不要改）：句长/段长不参差、单字虚词偏少、反复写全称、被动句、名词化长句本身、正文"首先其次"、句内同构排比、问句设问、比喻本身、抽象名词配具体动词。
"""


def pick_topic(hot, recent):
    hotlist = "\n".join(f"{i}. {h['title']}" for i, h in enumerate(hot, 1))
    prompt = f"""只输出 JSON，不要任何其他内容。不要思考过程，不要解释，不要 markdown 标记。

你是今日头条微头条账号「棱镜折射」的选题编辑。下面有两块信息。

【今天的热榜】
{hotlist}

【我们最近已经发过的（不能重复选题/重复角度）】
{recent or '（无）'}

从热榜里选 1 个最适合微头条的题目。选择优先级：民生利益（钱、假期、物价、养老、医疗、消费坑）> 职场/教育 > 生活常识 > 社会情绪。
【数据迭代 2026-09-14 · 硬性】同等条件下优先选**有具体当事人/金额/判决/合同的具体事件类**题目；纯趋势/观点/政策解读类（如"XX将成主流""XX的三重信号"）降权——实测具体事件类平均展现 1200+，泛议题类 <100。若只能选政策/趋势类，angle 必须落到"具体人的具体遭遇"场景（写看病就写某个病人在A医院重拍CT，不写政策条文）。
必须避开：与上面已发内容同主题或同角度的；政治、刑案、悲剧、明星八卦、体育赛事比分、纯国际新闻。

只输出 JSON，不要别的：
{{"topic": "选中的题目（照抄热榜原句）", "angle": "我们打算切的角度，一句话", "core_view": "核心观点，一句话", "known_facts": ["写稿时必须用到的已知事实/数字，没把握的不要写"], "rejected": "为什么没选其它题目，一句话"}}"""
    txt, model = llm(prompt, max_tokens=2000, temperature=0.4)
    # dots 是 reasoning 模型：content 字段可能包含思考过程，JSON 在最后。
    # 从后往前找最后一个合法的 JSON 对象。
    combined = txt
    combined = re.sub(r"```(?:json)?\s*", "", combined)
    combined = re.sub(r"```\s*$", "", combined)
    # 从后往前找 } 和 {，提取最后一个完整 JSON 对象
    end = combined.rfind("}")
    if end == -1:
        raise RuntimeError(f"选题模型没返回 JSON：{txt[:300]}")
    # 从 end 往前找匹配的 {
    depth = 0
    start = -1
    for i in range(end, -1, -1):
        if combined[i] == "}":
            depth += 1
        elif combined[i] == "{":
            depth -= 1
            if depth == 0:
                start = i
                break
    if start == -1:
        raise RuntimeError(f"选题模型没返回 JSON：{txt[:300]}")
    json_str = combined[start:end+1]
    try:
        data = json.loads(json_str)
    except json.JSONDecodeError as e:
        raise RuntimeError(f"选题模型 JSON 解析失败：{e} | JSON: {json_str[:200]}")
    data["_model"] = model
    return data


def write_draft(topic_info, recent):
    prompt = f"""只输出正文，不要任何其他内容。不要思考过程，不要解释，不要 markdown 标记。

给今日头条微头条账号「棱镜折射」写一条微头条。

【题目】{topic_info['topic']}
【切入角度】{topic_info.get('angle','')}
【核心观点】{topic_info.get('core_view','')}
【可用事实（只用这些，没把握的一律不要写）】{'；'.join(topic_info.get('known_facts') or []) or '（无，只能用常识性表述，不要编具体数字）'}

【最近发过的（避免结尾句式和内容撞车）】
{recent or '（无）'}

{STYLE}

现在直接写正文。"""
    txt, model = llm(prompt, max_tokens=2000, temperature=0.85)
    txt = txt.strip().strip('"').strip()
    # 去掉可能出现的标题行
    txt = re.sub(r"^(标题|题目)[:：].*\n+", "", txt)
    # dots reasoning 模型可能在 content 里带 "Thinking Process:" 前缀，
    # 剥离英文思考过程，只保留中文正文
    thinking_match = re.search(r"^(?:Thinking Process|思考过程|Reasoning|推理过程)[\s\S]*?(?=\n\n|\n(?=[\u4e00-\u9fff])|$)", txt, re.I)
    if thinking_match:
        remaining = txt[thinking_match.end():].strip()
        if remaining:
            txt = remaining
    # 也尝试找最后一个中文段落（以中文字符开头）
    zh_lines = [l for l in txt.split('\n') if l.strip() and re.search(r'[\u4e00-\u9fff]', l)]
    if zh_lines and len(zh_lines) < len(txt.split('\n')):
        # 有英文/思考过程混入，只保留中文行
        txt = '\n'.join(zh_lines).strip()
    return txt, model


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--hot", default="/tmp/wt_hot.json")
    ap.add_argument("--topic", default=None, help="跳过选题，直接写这个题目")
    ap.add_argument("--topic-file", default=None, help="读 /tmp/wt_topic.json 里的选题信息来写稿")
    ap.add_argument("--facts", default="/tmp/wt_facts.json", help="事实清单文件（wt_facts.py 产出）")
    ap.add_argument("--stage", default="all", choices=["all", "pick", "write"],
                    help="pick=只选题；write=只写稿；all=选题+写稿")
    ap.add_argument("--out-draft", default="/tmp/wt_draft.txt")
    ap.add_argument("--out-topic", default="/tmp/wt_topic.json")
    a = ap.parse_args()

    recent = load_ledger_recent_text(6)

    if a.stage == "pick":
        hot = json.load(open(a.hot, encoding="utf-8"))
        if not hot:
            raise RuntimeError(f"{a.hot} 里没有热榜数据，先跑 wt_hotlist.py")
        topic_info = pick_topic(hot, recent)
        print(f"[gen] 选题模型：{topic_info.get('_model')}", file=sys.stderr)
        print(f"[gen] 选中：{topic_info['topic']} —— {topic_info.get('angle','')}", file=sys.stderr)
        print(f"[gen] 排除理由：{topic_info.get('rejected','')}", file=sys.stderr)
        json.dump(topic_info, open(a.out_topic, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
        print(json.dumps(topic_info, ensure_ascii=False, indent=1))
        return

    if a.topic_file and os.path.exists(a.topic_file):
        topic_info = json.load(open(a.topic_file, encoding="utf-8"))
    elif a.topic:
        topic_info = {"topic": a.topic, "angle": "", "core_view": "", "known_facts": [], "_model": "skip"}
    else:
        hot = json.load(open(a.hot, encoding="utf-8"))
        if not hot:
            raise RuntimeError(f"{a.hot} 里没有热榜数据，先跑 wt_hotlist.py")
        topic_info = pick_topic(hot, recent)
        print(f"[gen] 选题模型：{topic_info.get('_model')}", file=sys.stderr)
        print(f"[gen] 选中：{topic_info['topic']} —— {topic_info.get('angle','')}", file=sys.stderr)
        print(f"[gen] 排除理由：{topic_info.get('rejected','')}", file=sys.stderr)

    # 合并 wt_facts.py 抓到的已核实事实
    if os.path.exists(a.facts):
        try:
            fx = json.load(open(a.facts, encoding="utf-8"))
            extra = fx.get("facts") or []
            if extra:
                topic_info["known_facts"] = extra + list(topic_info.get("known_facts") or [])
                topic_info["sources"] = fx.get("sources") or []
                print(f"[gen] 已并入 {len(extra)} 条外部核实事实", file=sys.stderr)
        except Exception as e:
            print(f"[gen] 事实文件读取失败（忽略）：{e}", file=sys.stderr)

    draft, model = write_draft(topic_info, recent)
    topic_info["_write_model"] = model
    topic_info["chars"] = len(re.sub(r"\s", "", draft))
    json.dump(topic_info, open(a.out_topic, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    open(a.out_draft, "w", encoding="utf-8").write(draft + "\n")

    print(f"\n===== 选题 =====")
    print(topic_info["topic"])
    print(f"===== 正文（{topic_info['chars']} 字，模型 {model}）=====")
    print(draft)
    if not (380 <= topic_info["chars"] <= 560):
        print(f"\n[gen][警告] 字数 {topic_info['chars']} 偏离 400-500 区间，需要重写或调整", file=sys.stderr)


if __name__ == "__main__":
    main()
