---
name: cron-pipeline-ops
description: "Use when cron 内容流水线模型接线或发布自动化报错、要加固。"
---

# 定时任务型内容流水线的运维（模型接线 · 发布自动化 · 排错）

面向“cron 定时跑一条内容流水线（写稿→复审→浏览器发布→记录）”这类任务的运维与排错。
沉淀自 2026-09-13 一次完整实战：微头条 cron 任务连续失败 → 逐层定位到 provider 名写错、模型漂移、上游响应包壳、免费模型限流与能力不足，并全部修复。

## 何时用
- cron 任务 `last_status=error` / 平台上看不到新内容 / “该发的东西没发出去”
- 报 `Invalid API response ... choices is None`、`HTTP 400 ... model names are ...`、`429`、`drift_skip`
- 要给 cron 任务换模型 / 换 provider / 配 fallback 链
- 任务“跑完了但没交付”（半途交卷、重复发布、内容残留）

## 排错顺序（照这个走最快）

1. **先看任务真实状态与错误原文**（`hermes cron list` / `~/.hermes/cron/output/<job_id>/*.md` / `~/.hermes/cron/executions.db`），别凭平台页面现象猜。
2. **分辨模型调用走的是哪条路**：`grep "OpenAI client created" ~/.hermes/logs/agent.log | tail`
   - `chat_completion_request` = **非流式**（cron / 子代理走这条）
   - `chat_completion_stream_request` = 流式（CLI / 网关聊天）
   → 同模型在聊天里正常、在 cron 里报 `choices is None`，基本就是“上游只在流式下返回标准格式”，见下。
3. **响应包壳**：上游把响应包成 `{"data": {...}, "success": true}`（顶层无 `choices`），而 cron 走非流式 → 用本地解包代理 + 自定义 provider（`scripts/cline_unwrap_proxy.py`；安装与 provider 配置见 `references/hermes-cron-model-ops.md`）。
4. **provider 名 / pin 是否正确**：`hermes cron edit --provider <名>` **不校验 provider 名**，写错的会被静默接受并在触发时回落到全局 provider（→ 上游 400）。pin 完必须复核落盘值（`hermes cron list` 或 `~/.hermes/cron/jobs.json`）。
5. **模型漂移**：全局 provider/model 改过后，未 pin 的旧任务会被 `drift_skip` 保护性跳过。显式 pin，**首选 pin 成与当前全局一致的值**。
6. **限流**：免费模型 `429` 很常见 → 配 `fallback_providers` 链（`hermes config set fallback_providers '<JSON数组>'`，元素 `{provider, model}`），主模型失败自动下切。
7. **模型能力**：链路通了不等于任务能完成，弱模型会半途交卷/编造内容/空转（见下）。
8. **输入 token 配额**：主模型小请求能过 ≠ 能当 cron 大脑——上游按分钟算输入 token 上限，而长流程会话上下文会涨到 6 万+，超限就是稳定 429（不是抖动）。429 原文里带 `input_token_count, limit: <N>, model: <X>` 即此症。见下节。
9. **空转**：`last_status=ok` 也可能是废的——跑满 20 分钟、几十次模型调用，最后只吐几十字符垃圾。拿到最终回复后**必须回外部世界核实**（平台列表/交付文件），别信状态字段。
10. **整链失效的根因判定（2026-09-15 实战补录）**：主模型 + fallback 全链报错时，先分清「上游模型坏」和「配置错」——用裸 curl 直连上游逐个测（key 从 `~/.hermes/.env` 读）。要点：① 同一模型在不同调用路径可用性可能不同（glm-5.3-flash 当天 cron 路径稳定 500，交互会话正常）；② 免费池抖动是小时级——先等 60s 重测，通了就是瞬时抖动别改配置；③ 换模型前给用户实测证据；④ **用户规矩：换 cron 任务模型必须经用户同意**，换完回读 jobs.json + cron list 双确认；⑤ cronjob 工具接口不支持改 model 字段，直接改 `~/.hermes/cron/jobs.json`。详见 `references/cron-model-swap-notes.md`。

详细命令与实测数据：`references/hermes-cron-model-ops.md`。

## 验证配方（都不产生副作用）

```bash
# ① provider + 模型 + key 是否可用
hermes -z "只回复两个字：正常" --provider <p> -m <m> -t ""

# ② 验证 cron 路径（非流式）而不发真内容：临时任务 + deliver=local
hermes cron create "in 6h" "只回复 PROBE-OK，不要调用任何工具" --deliver local --provider <p> --model <m>
hermes cron run <临时任务id>        # 结果看 ~/.hermes/cron/output/<id>/*.md
hermes cron remove <临时任务id>     # 验完删掉

# ③ 上游响应形状（判断是否包壳）
curl -s -X POST <base_url>/chat/completions -H "Authorization: Bearer $KEY" -H 'Content-Type: application/json' \
  -d '{"model":"<m>","messages":[{"role":"user","content":"OK"}],"stream":false}' \
  | python3 -c "import json,sys;d=json.load(sys.stdin);print(list(d.keys())[:5], bool(d.get('choices')))"
```

**铁律**：任务自己的回执是**自报**，不等于事实。发布/写入类副作用必须回到外部世界核实（平台后台列表、落盘文件、实际内容）。

## 弱模型驱动多步任务：两个典型症状与对策

| 症状 | 现象 | 对策 |
|---|---|---|
| 半途交卷 | 把“下一步计划”当最终回复（如“P1-P4 已写入，继续写入 P5-P7”就结束） | prompt 硬性加：**禁止把进度说明当最终回复**；成功后才能结束；最后一行必须是 `RESULT: 已完成 <结果>` / `RESULT: 未完成 <卡在哪+报错原文>` |
| 能力不足 | 能调工具但撑不住长流程，中途编造内容 | 换能跑完流程的模型；上线前用“4 步探测”（web_search→terminal→read_file→汇总）筛一遍候选模型 |
| 空转后吐垃圾 | `last_status=ok`、日志说 completed，但最终回复只有几十字符碎片（如 `537 characters -512</parameter>`，工具调用残渣），外部世界零产出。日志特征：`api_calls` 很高而 `response_len` 极小 | 先用模型分布定位是否被 fallback 换成了弱模型；换回能吃长上下文的主模型 + prompt 加“禁止空转/限时/禁止垃圾回复”条款（见「空转」一节） |

选型参考（2026-09-13 实测 19 个 `:free`）：能跑完多步流程的 `google/gemma-4-26b-a4b-it` / `dots-studio/dots-3-note-preview` / `nvidia/nemotron-3-super-120b-a12b`；单轮文本强但撑不住长流程的 `cohere/north-mini-code:free`；基本不干活的 `nvidia/nemotron-3.5-content-safety`（输出 15-52 字）、`nvidia/nemotron-3.5-lightning`（单次 90-200s 必超时）、`z-ai/glm-5.3-flash`（全 429）。**`:free` 必须实跑验证，别信名字。**

## 免费模型的两类结构性坑：输入 token 配额 & 空转吐垃圾

**A. 输入配额是结构性的，不是抖动。** 实测 `google/gemma-4-26b-a4b-it:free` 单人小任务上很好，但设成 cron 主模型后**每班必挂**：上游对 gemma-4-26b 的 `input_token_count` 上限 16000/分钟，而这类流水线会话上下文起步 6 万+ token → 每个请求都超限 → 3 次重试全 429 → 自动 fallback（fallback 到的弱模型接着空转）。
**pin 主模型要同时看两个维度**：①能不能多步调用工具 ②输入额度能不能吃下 6 万+ token。只满足①的模型只能在单轮小任务上用，不能当大脑。实测能吃长会话的免费主力：`dots-studio/dots-3-note-preview:free`。探活用 `scripts/probe_free_models.py`（同时问“能跑完流程吗”和“能吃长上下文吗”）。

**B. 空转 → 垃圾回复**：任务显示成功，实际零交付。日志级排查 4 步（输出/会话/模型分布/结局）与 prompt 层三条加固（禁止空转、限时收尾、禁止垃圾回复）见 `references/cron-empty-spin-triage.md`。

**C. reasoning 模型在「流式」下会把正文塞进 `reasoning`，脚本解析不出内容（2026-10-01 定位，重要）。** 症状：脚本化流水线的选题/写稿步骤反复报「❌ 选题失败（免费模型全挂或返回不可解析）」，但同一模型在别处能用；手工 curl 看得到输出来，所以很像"没返回"而不是"返回了但拿不到"。根因：`dots-studio/dots-3-note-preview:free` 这类 reasoning 模型，**`stream=True` 时正文和思考过程一起落在 `reasoning` 字段，`content` 为空**；脚本只读 `content` 就是空字符串。
修法（已验证）：对 dots/reasoning 模型改用 **`stream=False` + `reasoning_effort="low"` + `max_tokens≥8000`**，此时 `content` 字段直接是干净 JSON、`reasoning` 里只剩思考过程。三个参数缺一不可——单加 `reasoning_effort` 而不改 `stream` 无效；`max_tokens` 给太小（如 2000）会让 reasoning 吃满、content 没空间。
→ 教训：**「模型没返回」和「脚本没读对字段」要先分清楚**；修此类问题时要先把原始响应（完整 SSE/JSON）打出来看字段分布，别直接换模型。

## 长流程任务：别用前台等（420s 上限）
整条「抓榜→选题→抓事实→写稿→终审改稿×2→发布」实测 **8-12 分钟**。前台 `terminal` 有 420s 上限，会在跑到一半时被 kill，看起来像「失败」其实只是被截断。正确姿势：`terminal(background=true)` 起，再用 `process(action='wait')` / `poll` 收结果；进度看落盘日志。别反复前台重跑同一班——脚本里的 `flock` 只会让后来者跳过，白等一轮。

## 调度频率不是越高越好（用户改频率时先算三笔账）

把任务从「每 2 小时」改成「每小时」之前先算：
1. **单条实际耗时 ≤ 间隔**：写稿+复审+终审+发布实测 15-25 分钟，间隔压到 1 小时就会与下一班撞（执行锁不会并发出两条，但会出现"这班没跑完、下班被跳过"）。
2. **查重压力**：一天 24 条时选题池几天被抽空，同主题/同角度重复率陡增，台账查重会越来越难。
   实测推演（2026-10-03）：池子 171 条 + 图集 job 每小时 1 条，再叠上“草稿箱清理任务把删掉的图集草稿对应话题**永久摘掉**” → **每天淘汰约 24 个关键词，约 7 天见底**。见底后若 `TOPICS` 为空会 `TOPICS[0]` 越界崩，所以 `load_topics()` 末尾要有 `or list(_SEED_TOPIC)` 兜底（已加）——但兜底只防崩，实际等于反复用同一个词、**流水线停摆**。给用户提的三条路：① 加每日补池任务（每天 ~30 条、维持 200 条）② 降频（每天 6 条可撑 ~28 天）③ 关键词改“用过就标记”，转完一圈整体重置。
   → 教训：**“清草稿”和“删关键词”联在一起时，要顺手算一遍池子消耗速度**；否则两周后回来处理的是“流水线卡死”，而不是“草稿箱太满”。
3. **平台风控与日发上限**：高频批量发布易被判"营销号/低质批量"；免费模型额度也可能扛不住（表现为重试变多、整体变慢）。

比单纯提频率更划算的做法：加「同一小时已有发布记录就跳过」的护栏 + 要求相邻两条不同赛道。改完把间隔、单条耗时、下一步触发时间一起回报给用户。

### 关键词池的处置：已定案（2026-10-03）——别再提案

上面那三条路用户已经拍过板：**永久删、不冷却、不自动补池**。原话：「永久删。不用自己补，需要补的时候我会找你的」。

- **不要自作主张加「冷却 / 用过回收」机制，也不要挂自动补池任务。** 补词是用户的决定，他会在需要时开口。（曾经把「冷却」当作推荐方案提出来，被明确否掉。）
- 代价用户已知晓并接受：池子见底后图集线靠种子词兜底继续跑，题材变单调，但不会崩。
- 因此**每次清理都要主动播报池子余量**，把「该补词了」这件事从用户的记忆里卸下来：脚本加一个 `pool_status(retired_today)`，打印
  `话题池剩 N 个关键词（今天淘汰 X 个，按此速度还能撑约 D 天）`，`N < 40` 时前缀 ⚠️ + 「该补词了，跟我说一声」。**每一条退出路径都要打印**（草稿箱为空 / 无需改动 / dry-run / 正常删完）——只在「删了东西」时打印的话，草稿箱恰好空的那几天不报，用户会以为任务没跑。
  → 通用做法：**定时消耗有限资源池**的流水线，每班输出里都带「剩余额度 + 还能撑几天」和阈值告警。用户偏好「自己决定何时补充」，那就把「什么时候该补」算给他看，而不是替他补。

## 浏览器发布类步骤的硬规矩

1. **调度会话里禁止手写 heredoc 跑浏览器脚本**：heredoc 会被截断（`here-document ... delimited by end-of-file`），脚本只跑一半。改用现成的浏览器工具（如 `browser_exec`，含 `goto_url / wait_for_load / js / cdp / click_at_xy`）。
2. **填内容前先清空编辑器**：残留内容会与本次拼接成“两篇”，字数翻倍。`Ctrl+A` + `Backspace`，回读确认后再填。
3. **不可逆动作只做一次**：发布/提交按钮重复点会重复发布（实测同题发了 3 条，事后手动删 2 条）。
4. **React 下拉菜单要用真实鼠标事件**：`element.click()` 不一定开菜单，用 `cdp('Input.dispatchMouseEvent', type='mousePressed'/'mouseReleased')`。
5. **登录态会过期**，且多个平台可能共用同一个浏览器 profile（cookie 按域隔离）；发布前先确认页面不是登录页。

## 外部模型复盘（把交付物喂给另一个模型挑刺）

任务自己能过审，不等于内容/结果没毛病。把当天产出整批喂给外部模型（网页端开“深度思考”+联网搜索）复盘，常能挖出自己脚本抓不到的问题（事实口径、重复套路、结构同质化）。
登录、发送、抓回复的具体操作与坑（图形验证码、短信延迟、虚拟渲染抓不到文本）见 `references/web-chat-automation.md`。

**把终审做成流水线的固定步骤**（不只是事后复盘）：改成脚本化、裸 CDP 驱动、返回机器可读判定（`VERDICT: PASS/FIX`），放在发布前当闸门；写法与坑见 `references/web-chat-automation.md` 的「脚本化终审」一节，本次落地脚本 `~/.hermes/skills/toutiao-micro-publish/scripts/ds_web_review.py`。

## 代理/出网的测量陷阱

做“直连 vs 代理”对比前先 `env | grep -i proxy`：本机 shell 全局设了 `http_proxy/https_proxy`（mihomo mixed-port），否则会把两次都走代理的结果误读成“代理无效”。要真直连就 `curl --noproxy '*'`。

## 发布前事实/口径门禁（内容类流水线）

发布类任务的最后一道闸门：复审脚本只抓「AI 味」，**抓不出事实错误**。实测一次外部复盘就从当天 5 条里找出 5 处事实/口径问题（数据口径写错、统计数字论证方向反了、二手名次当事实、自建估算未标注、选择性引用）。完整六条门禁 + 同日多条的结尾/情绪/结构配额 + 复盘 prompt 模板见 `references/pre-publish-fact-gate.md`；可把它当作发布前的 checklist 跑一遍。

## 识图能力（`vision_analyze`）的后端接线

识图走 `auxiliary.vision`，与主模型是**两套**配置。`provider: auto` 时可能落到额度耗尽的第三方，报 `402 insufficient_credits`——**看起来像「没有识图能力」，实际是接错后端**。

```bash
hermes config set auxiliary.vision.provider deepseek
hermes config set auxiliary.vision.model deepseek-flash
```

- ⚠️ **`~/.hermes/config.yaml` 受保护，agent 直接 write/patch 会被拒**（会提示“编辑 ~/.hermes/config.yaml 或使用 hermes config”），必须走 `hermes config set`。
- 修好后优先用 `vision_analyze` 而不是“让别的模型描述再读描述”：它把图**载入 agent 自己的上下文**，看得准；外部描述会前后矛盾（实测同一张图被判“朝右/朝左/正前”各一次），会把不合格成品判成合格。
- 兜底：图转 base64 data URL 塞进主模型 `chat/completions` 的 `image_url`（主模型支持读图时可用）。
- **第二条免 key 识图通道：`chat.deepseek.com` 网页版能上传图片并真的能看图**（2026-10-03 实测）。
  - 页面里有隐藏的 `input[type=file]`（accept 含 `.png/.jpg/.jpeg/.webp`），用裸 CDP 的 `DOM.setFileInputFiles(files=[路径], nodeId=...)` 直接塞文件（`DOM.getDocument` → `DOM.querySelector` 拿 nodeId），**不用模拟点击**；附上后 composer 会出现 blob 缩略图。
  - 实测提问“这张图里是什么？”→ 回答准确（认出“粉色圆滚滚的卡通老鼠”，不是“我看到图片了”式敷衍），说明是真看图。
  - 填字要用 **native setter**：DeepSeek 是 React 受控 textarea，`ta.value = x` 不生效，得 `Object.getOwnPropertyDescriptor(HTMLTextAreaElement.prototype,'value').set.call(ta, x)` + 派发 `input` 事件；发送用 `Input.dispatchKeyEvent` 回车；正文仍取 `[class*=markdown]`。
  - 定位：免额度、不烧 token，但要起浏览器/要登录态/更慢 → 日常用 `vision_analyze`（走 API），需要交叉验证或 API 报错时切网页版。
- 详细的成对图生成、pollinations 限流与水印、Pexels 相关性抽查见 `references/image-sources.md`。

## 支持文件
- `references/hermes-cron-model-ops.md` — 四层根因实战记录、判定命令、日志/证据位置、免费模型实测表
- `references/web-chat-automation.md` — 驱动网页版大模型：browser_exec 手动路径（登录/验证码/发送/抓回复）+ 裸 CDP 脚本化终审（后台标签节流、容器选择、VERDICT 解析、fail 策略）+ 裸 CDP 连 9222 通用坑（browser-harness 403 → 裸 websocket `suppress_origin=True`、Chrome 看门狗、列表页等 8s 渲染后用 innerText+分隔符解析）
- `references/cron-agent-output-discipline.md` — agent 版 cron 输出纪律：报告正文一律落盘、最终回复只给短摘要（超长截断→整轮判 FAILED 的首跑事故实录）
- `references/pexels-topic-exhaustion.md` — 图集话题池：枯竭根因（台账消耗 ≈ 检索深度）+ md5 台账感知选题（超阈值排除）、**什么时候该换池（反复打“所有候选话题均已发≥30张”）、换池/扩充完整工作流与相关性抽查（英文词搜得到≠图对，含实例）、topics.json 格式不匹配会静默失效**、补丁变量作用域乌龙与 dry-run 立验教训
- `references/pipeline-dual-output.md` — 图集流水线双输出架构：压缩版进草稿箱 + 全尺寸版通过 MEDIA: 推给用户（绕过微信素材库大小限制）。含 compress_image 兜底缩分辨率、process_image 大图降采样、batchget 必须 POST、newspic 图片在 image_info 不在 content 等踩坑。
- `references/pre-publish-fact-gate.md` — 发布前事实/口径六条门禁、同日多条配额、外部复盘 prompt 模板
- `references/cron-empty-spin-triage.md` — “任务成功但零交付”的日志级排查（会话 id 反推、模型分布统计、配额 429 原文、输出文件时间戳语义）+ prompt 层防空转条款
- `scripts/probe_free_models.py` — 免费模型探活：小请求 + 几千字长输入两档，识别“小请求能过、长上下文必 429”的假可用
- `scripts/cline_unwrap_proxy.py` — 响应包壳解包代理（本地 OpenAI 兼容 shim，可 systemd 常驻）
- `references/gzh-article-publish-notes.md` — 公众号文章线：写作 skill 真实名字（发布 skill 里的引用是悬空的）、六步实录命令、发布后 HTML 标签自检表、汇报格式
- `references/cron-model-swap-notes.md` — 换 cron 任务模型实操（cronjob 接口不支持改 model→直接改 jobs.json、双确认落盘、用户同意规矩）与整链失效根因判定（同模型不同路径可用性不同、免费池小时级抖动先重测再改配置）
- `references/wechat-draft-api-content-types.md` — 公众号草稿 API：`newspic` vs `news` 的 content 能力差异（图片消息只存纯文本→小程序链接必须走图文消息）、三种小程序链接 HTML 写法、`draft/batchget` vs `draft/getdraft` 接口名坑、`freepublish/batchget` 48001、逐条验证矩阵
- `references/image-sources.md` — 免 key 配图素材全谱：(A) Pexels 实拍（含相关性抽查坑：地名英文词“搜得到≠图对”、额度 200/小时）(B) pollinations 生图（尺寸上限、水印必存+裁切尺寸、约一半请求空文件需重试、提示词约束力有限）(C) 看图验证硬规矩 **(D) 成对图/情侣头像：一次生成整幅再切开 + PIL 分区染色 + 90% 安全边距 + 圆形裁切自查（别分两次生成）** (E) `vision_analyze` 后端接错导致 402 的修法。urllib 403 → 必须 curl + UA。
- `references/gallery-draftbox-ops.md` — 公众号图集/草稿线运维：**草稿箱批量清理**（按 `update_time` 切分 + 先分类保护用户手写稿 + 分类规则写窄的坑 + 后台计数与 API 对不上）、**保留策略自动化**（`prune_drafts.py` / cron `e11f232f4c79`；“图集草稿 vs 日更文章稿”两类要分清；双源同步必须双备份；空池子越界兜底；端到端验证套路；**关键词池“永久删、不冷却、不自动补池”已定案 + 每班播报剩余额度/还能撑几天**）、`process_image()` OOM 修法（整图 float64 噪声 → 分块 float32，2G 小机器必踩）、**贴图(newspic) vs 图文(news) 版式取舍已定案**（要可点小程序链只能 news）。
