#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
每小时公众号图集草稿：Pexels 抓 9 张横图 → 左右翻转+滤镜(不叠字) → 传微信素材 → 建草稿箱贴图(newspic)

用法:
  python3 pexels_gallery_draft.py [--topic 秋天] [--count 9] [--dry-run]

md5 去重（2026-08-29 用户要求）:
  - 下载原图后立即计算 md5，查台账 logs/gallery_sent_md5.json，发过的图片直接剔除不重复发
  - 仅在草稿创建成功后才把本次 md5 写入台账（失败不记录，可重试）
  - 台账结构: {"md5s": {"<md5>": {"pexels_id":..,"topic":..,"ts":..}}, "list": [...]}

依赖: Pillow + requests + numpy（wechat-ai-publisher 环境已有）
配置: Pexels key 从 douyin-card-pipeline/config.json 读; 微信 .env 从本 skill 目录读
"""
import os, sys, json, random, shutil, argparse, tempfile, hashlib, glob, time
import requests
from datetime import datetime

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, SCRIPT_DIR)
import config as wc_config
import compress_image

# ---------- 话题池：中文名 → Pexels 英文搜索词 ----------
# 话题池独立存于 scripts/topics.json（每3天由 expand_topics.py 补充），脚本优先读它；
# 若文件缺失则回退到下方内置列表。
TOPICS_JSON = os.path.join(SCRIPT_DIR, "topics.json")

def load_topics():
    if os.path.exists(TOPICS_JSON):
        try:
            data = json.load(open(TOPICS_JSON, encoding="utf-8"))
            pairs = []
            for d in data:
                if isinstance(d, dict):
                    cn, en = d.get("cn"), d.get("en")
                elif isinstance(d, (list, tuple)) and len(d) >= 2:
                    cn, en = d[0], d[1]
                else:
                    continue
                if cn and en:
                    pairs.append((cn, en))
            if pairs:
                return pairs
        except Exception as e:
            print(f"! 读取 topics.json 失败({e})，回退内置列表", file=sys.stderr)
    return _BUILTIN_TOPICS or list(_SEED_TOPIC)


# 池子被掏空（topics.json 与内置表同时为空）时的种子，保证脚本不越界崩溃
_SEED_TOPIC = [("雪山金顶", "snow mountain golden sunrise")]


_BUILTIN_TOPICS = [
    ("伊犁杏花", "ili apricot blossom valley"),
    ("呼伦贝尔草原", "hulun buir grassland"),
    ("喀纳斯湖", "kanas lake autumn"),
    ("巴音布鲁克", "bayanbulak grassland swamp"),
    ("扎龙湿地", "zhalong wetland red crown"),
    ("极光雪原", "aurora borealis snow field"),
    ("桂林山水", "guilin karst landscape"),
    ("梯田晨雾", "rice terraces morning mist"),
    ("武隆天生桥", "wulong natural bridge karst"),
    ("沙漠胡杨", "poplar forest desert autumn"),
    ("海岸悬崖", "coastal cliffs ocean"),
    ("海蚀地貌", "sea rock coastline erosion"),
    ("湿地候鸟", "wetland migratory birds"),
    ("瀑布群落", "waterfall cascade jungle"),
    ("火山熔岩", "volcano lava landscape"),
    ("白桦林", "birch forest autumn"),
    ("盐湖倒影", "salt flat mirror reflection"),
    ("秋日枫林", "maple forest red autumn"),
    ("芦苇荡", "reed marsh wetland autumn"),
    ("草原晨光", "grassland sunrise prairie"),
    ("薰衣草田", "lavender field provence"),
    ("那拉提草原", "nalati grassland"),
    ("长城日落", "great wall sunset"),
    ("雅鲁藏布", "ygrand canyon river gorge"),
    ("雨林溪流", "rainforest stream waterfall"),
    ("雪山日落", "snow mountain sunset alpenglow"),
    ("雪山金顶", "snow mountain golden sunrise"),
    ("冰川湖", "glacial lake turquoise"),
    ("油菜花田", "rapeseed flower field"),
    ("萤火虫森林", "fireflies night forest"),
    ("樱花小径", "cherry blossom path"),
    ("桃花林", "peach blossom orchard"),
    ("雾漫山峦", "foggy mountain range layers"),
    ("青海湖", "qinghai lake blue"),
    ("额济纳胡杨", "ejina poplar forest autumn"),
    ("高山杜鹃", "alpine rhododendron bloom"),
    ("高山野花", "wildflower alpine meadow"),
    ("热带海岛航拍", "tropical island aerial"),
    ("蓝冰洞", "glacier ice cave"),
    ("雪原日出", "snowfield sunrise cold"),
    ("高原湖泊", "plateau lake mountains"),
    ("温泉雾气", "hot spring steam winter"),
    ("峡谷晨曦", "canyon sunrise mist"),
    ("沙漠绿洲", "desert oasis palm trees"),
    ("云瀑", "cloud waterfall mountain ridge"),
    ("茶山", "tea plantation hills"),
    ("富士山湖景", "mount fuji lake reflection"),
    ("纽约中央公园", "central park new york autumn"),
    ("布莱德湖", "lake bled slovenia"),
    ("马特洪峰", "matterhorn switzerland"),
    ("多洛米蒂", "dolomites italy mountains"),
    ("香山红叶", "autumn red leaves mountain china"),
    ("瘦西湖", "slender west lake"),
    ("黄山云海", "mount huang sea of clouds"),
    ("黄河九曲", "yellow river bends landscape"),
    ("黄河入海", "yellow river meets sea sunset"),
    ("黄河壶口", "hukou waterfall yellow river"),
    ("鼋头渚", "wuxi taihu lake"),
    ("千岛湖", "qiandao lake"),
    ("普陀山", "putuo mountain"),
    ("三清山", "sanqingshan mountain"),
    ("庐山", "mount lu"),
    ("龙虎山", "longhu mountain"),
    ("霞浦滩涂", "xiapu china fishing"),
    ("岳麓山", "yuelu mountain"),
    ("洞庭湖", "dongting lake"),
    ("神农架", "shennongjia forest"),
    ("三峡", "three gorges yangtze"),
    ("恩施大峡谷", "enshi grand canyon"),
    ("青城山", "qingcheng mountain"),
    ("四姑娘山", "siguniang mountain"),
    ("海螺沟", "hailuogou glacier"),
    ("牛背山", "niubei mountain"),
    ("元阳梯田", "yuanyang rice terraces"),
    ("玉龙雪山", "jade dragon snow mountain"),
    ("西双版纳", "xishuangbanna rainforest"),
    ("荔波小七孔", "libo xiaoqikong"),
    ("万峰林", "wanfenglin karst"),
    ("张掖丹霞", "zhangye danxia"),
    ("月牙泉", "crescent lake dunhuang"),
    ("茶卡盐湖", "chaka salt lake"),
    ("帕米尔高原", "pamir plateau"),
    ("赛里木湖", "sayram lake"),
    ("塔克拉玛干", "taklamakan desert"),
    ("沙坡头", "shapotou desert"),
    ("秦岭", "qinling mountains"),
    ("长白山", "changbai mountain"),
    ("松花江雾凇", "rime ice jilin"),
    ("纳木错", "namtso lake"),
    ("羊卓雍措", "yamdrok lake"),
    ("冈仁波齐", "mount kailash"),
    ("阿尔山", "arshan forest"),
    ("巴丹吉林沙漠", "badain jaran desert"),
    ("阿里山", "alishan mountain"),
    ("垦丁", "kenting beach taiwan"),
    ("非洲象", "african elephant savanna sunset"),
    ("长颈鹿", "giraffe savanna sunset acacia"),
    ("狮子", "lion savanna golden light"),
    ("斑马群", "zebra herd savanna"),
    ("狼群", "wolves snow winter pack"),
    ("红狐", "red fox winter snow"),
    ("驯鹿迁徙", "reindeer migration tundra"),
    ("野马群", "wild horses running steppe"),
    ("骏马奔驰", "horses galloping beach sunset"),
    ("羊群", "sheep flock green hillside"),
    ("牦牛", "yak tibetan plateau grassland"),
    ("骆驼商队", "camel caravan desert dunes"),
    ("北极熊", "polar bear ice arctic"),
    ("雪豹", "snow leopard mountain rock"),
    ("大熊猫", "giant panda bamboo forest"),
    ("金丝猴", "golden monkey forest"),
    ("东北虎", "siberian tiger snow forest"),
    ("天鹅湖", "swans lake mist morning"),
    ("丹顶鹤", "red crowned crane wetland"),
    ("孔雀开屏", "peacock displaying feathers"),
    ("蜂鸟", "hummingbird flower macro"),
    ("候鸟迁徙", "migratory birds flock sky"),
    ("雄鹰翱翔", "eagle soaring mountain sky"),
    ("猫头鹰", "owl forest branch"),
    ("座头鲸", "humpback whale ocean breach"),
    ("海豚", "dolphins jumping ocean"),
    ("鲨鱼", "shark underwater ocean"),
    ("海龟", "sea turtle coral reef"),
    ("发光水母", "jellyfish underwater glowing"),
    ("蝴蝶花海", "butterflies meadow flowers"),
]

TOPICS = load_topics()

PEXELS_CFG = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "..",
                          "douyin-card-pipeline", "config.json")
LOG_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "logs")
LEDGER_FILE = os.path.join(LOG_DIR, "gallery_sent_md5.json")
TOPIC_DAY_FILE = os.path.join(LOG_DIR, "gallery_topic_day.json")
UA = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
                    "(KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36"}


# ---------- 话题级去重（同一天不重复选话题） ----------
TOPIC_EXHAUSTED = 30   # 单话题累计已发超过此数视为检索池吃穿，选题时排除（2026-09-14）

def load_topic_usage(ledger):
    """从 md5 台账统计每个话题已发图片数: {"秋天": 79, ...}"""
    from collections import Counter
    return Counter(v.get("topic") for v in ledger.get("md5s", {}).values())

def load_topic_day():
    """读取当天已用话题记录: {"2026-08-29": {"topics": ["秋天", ...]}} """
    if os.path.exists(TOPIC_DAY_FILE):
        try:
            data = json.load(open(TOPIC_DAY_FILE, encoding="utf-8"))
            if isinstance(data, dict):
                return data
        except Exception:
            pass
    return {}


def record_topic_day(topic):
    """草稿创建成功后记录当天已用话题。"""
    today = datetime.now().strftime("%Y-%m-%d")
    data = load_topic_day()
    day = data.setdefault(today, {"topics": []})
    if topic not in day["topics"]:
        day["topics"].append(topic)
    tmp = TOPIC_DAY_FILE + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)
    os.replace(tmp, TOPIC_DAY_FILE)


# ---------- md5 台账 ----------
def load_ledger():
    """读取已发送图片 md5 台账。返回 {"md5s": {md5: info}, "list": [md5,...]}"""
    if os.path.exists(LEDGER_FILE):
        try:
            data = json.load(open(LEDGER_FILE, encoding="utf-8"))
            if "md5s" not in data:
                # 兼容旧格式 list
                md5s = {m: {"ts": "unknown"} for m in data.get("list", [])}
                data = {"md5s": md5s, "list": list(md5s.keys())}
            return data
        except Exception:
            pass
    return {"md5s": {}, "list": []}


def save_ledger(ledger):
    os.makedirs(LOG_DIR, exist_ok=True)
    tmp = LEDGER_FILE + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(ledger, f, ensure_ascii=False, indent=1)
    os.replace(tmp, LEDGER_FILE)


def record_sent(entries):
    """草稿创建成功后记录本次图片 md5。entries: [{md5, pexels_id, topic}]"""
    ledger = load_ledger()
    ts = datetime.now().isoformat()
    for e in entries:
        m = e["md5"]
        if m not in ledger["md5s"]:
            ledger["md5s"][m] = {
                "pexels_id": e.get("pexels_id"),
                "topic": e.get("topic"),
                "ts": ts,
            }
            ledger["list"].append(m)
    save_ledger(ledger)


def md5_file(path):
    h = hashlib.md5()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


# ---------- Pexels ----------
def get_pexels_key():
    if os.path.exists(PEXELS_CFG):
        data = json.load(open(PEXELS_CFG))
        key = data.get("pexels_api_key", "")
        if key:
            return key
    raise Exception("Pexels API key 未配置 (douyin-card-pipeline/config.json)")


def pexels_search(query, per_page=40, orientation="landscape"):
    import urllib.request, urllib.parse
    key = get_pexels_key()
    url = "https://api.pexels.com/v1/search?query=%s&per_page=%d&orientation=%s" % (
        urllib.parse.quote(query), per_page, orientation)
    req = urllib.request.Request(url, headers={"Authorization": key, **UA})
    with urllib.request.urlopen(req, timeout=30) as r:
        return json.loads(r.read()).get("photos", [])


def pexels_fetch(photo_id, out, original_url=None):
    """下载原图。优先用 API 返回的 src.original（全分辨率），否则退回压缩 URL。"""
    import urllib.request
    if original_url:
        url = original_url
    else:
        url = ("https://images.pexels.com/photos/%d/pexels-photo-%d.jpeg"
               "?auto=compress&cs=tinysrgb&w=1920&h=1080&fit=crop" % (photo_id, photo_id))
    req = urllib.request.Request(url, headers=UA)
    with urllib.request.urlopen(req, timeout=120) as r:
        data = r.read()
    with open(out, "wb") as f:
        f.write(data)
    return out


def process_image(src, dst):
    """左右翻转 + 滤镜（对比度/色彩/亮度微调）+ 轻噪点，不叠字。

    内存（2026-10-01 修复 OOM）：本机只有 ~2G 内存，原来 `np.random.normal(...)`
    会对整图生成 float64 噪声数组（2500×3750×3 → 225MB，加上加法/clip 的临时数组
    峰值 500MB+），9 张连跑必被 OOM Killer 干掉。改为 **float32 + 分行块** 加噪，
    峰值降到 ~150MB/张。超大图仍先缩到短边 ≤2500。
    """
    from PIL import Image, ImageEnhance
    import numpy as np
    im = Image.open(src).convert("RGB")
    w, h = im.size
    # 长边也设上限：竖图 2500×3750 的数组仍然很大
    if max(w, h) > 3000:
        ratio = 3000 / max(w, h)
        im = im.resize((int(w * ratio), int(h * ratio)), Image.LANCZOS)
    if min(w, h) > 2500:
        ratio = 2500 / min(w, h)
        im = im.resize((int(w * ratio), int(h * ratio)), Image.LANCZOS)
    im = im.transpose(Image.FLIP_LEFT_RIGHT)
    im = ImageEnhance.Contrast(im).enhance(random.uniform(1.05, 1.12))
    im = ImageEnhance.Color(im).enhance(random.uniform(0.95, 1.08))
    im = ImageEnhance.Brightness(im).enhance(random.uniform(0.98, 1.05))
    # 轻噪点（标准差 2-3.5）打散指纹：float32 + 逐行块，避免整图大数组
    sigma = random.uniform(2.0, 3.5)
    arr = np.asarray(im).astype(np.float32)
    band = 256
    for y in range(0, arr.shape[0], band):
        blk = arr[y:y + band]
        blk += np.random.normal(0.0, sigma, blk.shape).astype(np.float32)
        np.clip(blk, 0, 255, out=blk)
    out = Image.fromarray(arr.astype(np.uint8))
    del arr
    out.save(dst, "JPEG", quality=88)
    return dst


# ---------- 画质闸门（2026-10-03 新增，用户要求：不要模糊 / 灰暗陈旧的图）----------
# 锐度用「原图 3×3 分块里最锐的一块」的拉普拉斯方差，避免裁到大片天空/水面就误判成糊；
# 阈值按真实产物标定过：真图最低 65，人造模糊最高 140 → 取 150 可全拦模糊、误杀约 10%。
QC_SHARP_MIN = 150.0        # 常用阈值
QC_SHARP_MIN_HAZY = 60.0    # 雾景/夜景/星空本就柔，放宽
QC_SAT_MIN = 50.0           # 饱和度低于此
QC_CONTRAST_MIN = 45.0      # 且对比度也低于此 → 判为灰暗
QC_HAZY_TOPICS = {"松林晨雾", "云瀑", "温泉雾气", "峡谷晨曦", "雪原日出",
                  "银河星空", "极光湖面", "萤火虫森林", "蓝冰洞", "瀑布彩虹"}


def qc_sharpness(src, patch=512):
    """原图分块取最锐一块的拉普拉斯方差；比缩放到固定宽度可靠得多。"""
    import numpy as np
    from PIL import Image          # 本脚本 PIL 一贯函数内懒加载，模块级没有 Image
    im = Image.open(src)
    g = np.asarray(im.convert("L"), dtype=np.uint8)
    H, W = g.shape
    if min(H, W) < patch:                       # 小图退回整图计算
        gg = g.astype(np.float32)
        lap = -4 * gg + np.roll(gg, 1, 0) + np.roll(gg, -1, 0) + np.roll(gg, 1, 1) + np.roll(gg, -1, 1)
        return float(lap.var())
    best = 0.0
    for r in range(3):
        for c in range(3):
            y, x = (H - patch) * r // 2, (W - patch) * c // 2
            gg = g[y:y + patch, x:x + patch].astype(np.float32)
            lap = -4 * gg + np.roll(gg, 1, 0) + np.roll(gg, -1, 0) + np.roll(gg, 1, 1) + np.roll(gg, -1, 1)
            best = max(best, float(lap.var()))
    return best


def qc_dull(src, w=800):
    """缩到固定宽度估饱和度 / 对比度，用于识别灰蒙蒙、发闷的图。"""
    import numpy as np
    from PIL import Image
    im = Image.open(src)
    im.draft("RGB", (w * 2, w * 2))
    im = im.convert("RGB")
    if im.width != w:
        im = im.resize((w, max(1, round(im.height * w / im.width))), Image.LANCZOS)
    g = np.asarray(im.convert("L"), dtype=np.float32)
    sat = float(np.asarray(im.convert("HSV"), dtype=np.float32)[:, :, 1].mean())
    return sat, float(g.std())


def image_quality_ok(path, topic=""):
    """出图前的画质闸门 → (是否通过, 说明)。"""
    floor = QC_SHARP_MIN_HAZY if topic in QC_HAZY_TOPICS else QC_SHARP_MIN
    sharp = qc_sharpness(path)
    if sharp < floor:
        return False, f"模糊 sharp={sharp:.0f}<{floor:.0f}"
    sat, contrast = qc_dull(path)
    if sat < QC_SAT_MIN and contrast < QC_CONTRAST_MIN:
        return False, f"灰暗 sat={sat:.0f} contrast={contrast:.0f}"
    return True, f"ok sharp={sharp:.0f} sat={sat:.0f} contrast={contrast:.0f}"


# ---------- 微信 ----------
def _get_token(app_id, app_secret):
    from retry_util import request_with_retry
    r = request_with_retry('GET', "https://api.weixin.qq.com/cgi-bin/token",
        params={"grant_type": "client_credential", "appid": app_id, "secret": app_secret}, timeout=30)
    tok = r.json().get("access_token")
    if not tok:
        raise Exception(f"获取 access_token 失败: {r.json()}")
    return tok


def upload_image_material(app_id, app_secret, image_path):
    """上传永久图片素材（进素材库·图片分类 type=image），返回 media_id+url。"""
    from retry_util import request_with_retry
    tok = _get_token(app_id, app_secret)
    url = f"https://api.weixin.qq.com/cgi-bin/material/add_material?access_token={tok}&type=image"
    with open(image_path, 'rb') as f:
        files = {"media": (os.path.basename(image_path), f, "image/jpeg")}
        r = request_with_retry('POST', url, files=files, timeout=60)
    data = r.json()
    if data.get("errcode", 0) != 0:
        raise Exception(f"素材上传失败: {data}")
    if not data.get("media_id"):
        raise Exception(f"素材上传未返回 media_id: {data}")
    return data  # {media_id, url, ...}


# ---------- 小程序文字链（2026-10-01 起） ----------
# 关键：只有「图文消息」(news) 的 content 支持 HTML，才能放可点击的小程序文字链；
# 「图片消息」(newspic) 的 content 只支持纯文本，写 #小程序:// 也点不动（实测）。
MP_APPID = "wx489060715b335aaf"
MP_PATH = "pages/index/index"
MP_NICKNAME = "棱镜图库"
LINK_TEXT = "高清原图看这里👉 这组图真的每一张都能当壁纸！"


def _link_html():
    """正文末尾那行小程序文字链（整行可点击跳小程序）。"""
    return (
        f'<p><a data-miniprogram-appid="{MP_APPID}" '
        f'data-miniprogram-path="{MP_PATH}" '
        f'data-miniprogram-nickname="{MP_NICKNAME}" '
        f'data-miniprogram-type="text" href="">{LINK_TEXT}</a></p>'
    )


def _shrink_for_upload(src, dst, max_kb=900):
    """uploadimg 对大小敏感，压到 max_kb 以内（不动画质太多）。"""
    from PIL import Image
    im = Image.open(src).convert("RGB")
    q = 90
    im.save(dst, "JPEG", quality=q)
    while os.path.getsize(dst) > max_kb * 1024 and q > 50:
        q -= 10
        im.save(dst, "JPEG", quality=q)
    if os.path.getsize(dst) > max_kb * 1024:
        w, h = im.size
        im = im.resize((int(w * 0.7), int(h * 0.7)), Image.LANCZOS)
        im.save(dst, "JPEG", quality=80)
    return dst


def _draft_content(topic):
    """正文 HTML：图片在上，小程序文字链在末尾（图片由调用方拼在前面）。"""
    return _link_html()


def upload_content_image(app_id, app_secret, image_path):
    """上传正文内图片（uploadimg 接口），返回 mmbiz.qpic.cn URL。

    news 正文里的 <img> 必须用本接口的 URL，素材库的永久素材 URL 会被过滤。
    """
    from retry_util import request_with_retry
    tok = _get_token(app_id, app_secret)
    url = f"https://api.weixin.qq.com/cgi-bin/media/uploadimg?access_token={tok}"
    with open(image_path, "rb") as f:
        files = {"media": (os.path.basename(image_path), f, "image/jpeg")}
        r = request_with_retry('POST', url, files=files, timeout=120)
    data = r.json()
    if not data.get("url"):
        raise Exception(f"正文图片上传失败: {data}")
    return data["url"]


def create_news_draft(app_id, app_secret, title, content_html, thumb_media_id):
    """建「图文消息」草稿（article_type=news）。"""
    from retry_util import request_with_retry
    tok = _get_token(app_id, app_secret)
    article = {
        "article_type": "news",
        "title": title,
        "content": content_html,
        "thumb_media_id": thumb_media_id,
        "need_open_comment": 0,
        "only_fans_can_comment": 0,
    }
    url = f"https://api.weixin.qq.com/cgi-bin/draft/add?access_token={tok}"
    r = request_with_retry('POST', url,
        data=json.dumps({"articles": [article]}, ensure_ascii=False).encode("utf-8"),
        headers={"Content-Type": "application/json; charset=utf-8"}, timeout=60)
    data = r.json()
    if data.get("errcode", 0) != 0:
        raise Exception(f"建图文消息草稿失败: {data}")
    return data


def create_newspic_draft(app_id, app_secret, title, image_media_ids, content=""):
    """建「图片消息」草稿（草稿箱里的贴图，article_type=newspic）。"""
    from retry_util import request_with_retry
    tok = _get_token(app_id, app_secret)
    if len(image_media_ids) > 20:
        image_media_ids = image_media_ids[:20]
    article = {
        "article_type": "newspic",
        "title": title,
        "content": content,
        "need_open_comment": 0,
        "only_fans_can_comment": 0,
        "image_info": {
            "image_list": [{"image_media_id": mid} for mid in image_media_ids]
        },
    }
    url = f"https://api.weixin.qq.com/cgi-bin/draft/add?access_token={tok}"
    r = request_with_retry('POST', url,
        data=json.dumps({"articles": [article]}, ensure_ascii=False).encode("utf-8"),
        headers={"Content-Type": "application/json; charset=utf-8"}, timeout=30)
    data = r.json()
    if data.get("errcode", 0) != 0:
        raise Exception(f"建图片消息草稿失败: {data}")
    return data  # {media_id}


def main():
    ap = argparse.ArgumentParser(description="每小时公众号图集草稿（Pexels 9图→翻转滤镜→贴图草稿，md5去重）")
    ap.add_argument("--topic", default=None, help="指定话题（默认随机）")
    ap.add_argument("--count", type=int, default=9, help="图片数量（默认9）")
    ap.add_argument("--dry-run", action="store_true", help="只下载处理不上传不建草稿")
    ap.add_argument("--no-qc", action="store_true", help="关闭画质闸门（排错用）")
    ap.add_argument("--mode", choices=["news", "newspic"], default="news",
                    help="news=图文消息(可带小程序文字链) / newspic=贴图(无正文)。默认 news")
    args = ap.parse_args()

    if args.topic:
        topic, query = args.topic, args.topic
        for cn, en in TOPICS:
            if cn == args.topic:
                query = en
                break
    else:
        # 话题级去重：当天已用话题不再选，全部用完则重置循环
        used_today = load_topic_day().get(datetime.now().strftime("%Y-%m-%d"), {}).get("topics", [])
        available = [t for t in TOPICS if t[0] not in used_today]
        if not available:
            print(f"!!! 当天 {len(used_today)} 个话题已全部用过，重置循环", file=sys.stderr)
            available = TOPICS
        # 台账感知（2026-09-14 修复）：已发图片多的话题（Pexels 检索深度被吃穿）降权排除
        topic_used = load_topic_usage(load_ledger())
        fresh = [t for t in available if topic_used.get(t[0], 0) < TOPIC_EXHAUSTED]
        if fresh:
            available = fresh
        else:
            print(f"!!! 所有候选话题均已发 ≥{TOPIC_EXHAUSTED} 张，放宽限制", file=sys.stderr)
        topic, query = random.choice(available)
    print(f"话题: {topic}  (Pexels 查询: {query})", file=sys.stderr)

    sent = load_ledger()
    sent_set = set(sent["list"])
    print(f"台账已有 {len(sent_set)} 个已发 md5", file=sys.stderr)

    workdir = tempfile.mkdtemp(prefix="pexels_gallery_")
    # 用户可见输出目录：每次产出落盘 /tmp/gallery_out_<时间戳>/
    save_dir = os.path.join("/tmp", f"gallery_out_{datetime.now().strftime('%Y%m%d_%H%M%S')}")
    os.makedirs(save_dir, exist_ok=True)
    try:
        # 每次随机取横图或竖图
        ori = "landscape"   # 2026-10-03 用户要求：图集一律横版
        print(f"方向: {ori}", file=sys.stderr)
        # 1. 搜索 + 下载(跳过已发 md5 的重复图，多取候选补足)
        photos = pexels_search(query, per_page=args.count * 6, orientation=ori)
        if len(photos) < args.count * 2:
            fallback_q = TOPICS[0][1] if TOPICS else _SEED_TOPIC[0][1]
            photos += pexels_search(fallback_q, per_page=args.count * 3, orientation=ori)  # 兜底
        picked = []   # [(path, md5, pexels_id)]
        skipped = 0
        rejected = 0
        for p in photos:
            if len(picked) >= args.count:
                break
            # 只收符合本次随机方向的图
            if ori == "landscape" and p.get("width", 0) < p.get("height", 0):
                continue
            if ori == "portrait" and p.get("width", 0) >= p.get("height", 0):
                continue
            out = os.path.join(workdir, f"raw_{len(picked)+1}.jpg")
            try:
                pexels_fetch(p["id"], out, original_url=p.get("src", {}).get("original"))
            except Exception as e:
                print(f"  ! 下载失败 {p['id']}: {e}", file=sys.stderr)
                continue
            h = md5_file(out)
            if h in sent_set:
                skipped += 1
                print(f"  ! 剔除重复 md5={h[:12]} (pexels {p['id']})", file=sys.stderr)
                os.remove(out)
                continue
            # 画质闸门：糊的 / 灰暗的直接换下一张候选
            if not args.no_qc:
                ok, why = image_quality_ok(out, topic)
                if not ok:
                    rejected += 1
                    print(f"  × 画质不合格（{why}）pexels {p['id']}，换下一张", file=sys.stderr)
                    os.remove(out)
                    continue
                print(f"  ✓ 画质 {why}", file=sys.stderr)
            # 原图落盘到 save_dir（不压缩，用户可见）
            raw_out = os.path.join(save_dir, f"raw_{len(picked)+1}.jpg")
            shutil.copy(out, raw_out)
            picked.append((out, h, p["id"]))
            print(f"  + 下载 pexels {p['id']} md5={h[:12]} ({os.path.getsize(out)//1024}KB)", file=sys.stderr)
        if len(picked) < 3:
            raise Exception(f"有效图片不足3张（仅{len(picked)}张；剔除重复{skipped}张、画质不合格{rejected}张），放弃本次")

        # 2. 左右翻转 + 滤镜 → 产出两版：压缩版（≤600KB，草稿箱）+ 全尺寸版（不压缩，发微信）
        processed = []   # [(final_path, md5, pexels_id)]
        full_size = []   # [(full_path, md5, pexels_id)]  不压缩版
        for i, (src, h, pid) in enumerate(picked):
            dst = os.path.join(workdir, f"proc_{i+1}.jpg")
            process_image(src, dst)
            # 全尺寸版：翻转滤镜后直接存，不压缩
            full_dst = os.path.join(save_dir, f"full_{i+1}.jpg")
            shutil.copy(dst, full_dst)
            full_size.append((full_dst, h, pid))
            # 压缩版
            c_dst = os.path.join(workdir, f"final_{i+1}.jpg")
            compress_image.compress_image(dst, c_dst, max_size_kb=600)
            processed.append((c_dst, h, pid))
        print(f"处理完成 {len(processed)} 张（翻转+滤镜；剔除重复{skipped}张、画质不合格{rejected}张）", file=sys.stderr)

        if args.dry_run:
            print(json.dumps({"dry_run": True, "topic": topic,
                              "files": [p for p, _, _ in processed],
                              "skipped_dup": skipped, "rejected_qc": rejected}, ensure_ascii=False, indent=2))
            return

        # 3. 上传：封面（永久素材 → thumb_media_id）+ 正文图（uploadimg → URL）
        cfg = wc_config.get_wechat_config()
        app_id, app_secret = cfg["app_id"], cfg["app_secret"]
        if not app_id or not app_secret:
            raise Exception("微信 .env 配置缺失")

        # 封面：用第 1 张压缩图（永久素材，≤600KB 稳过 2M 限制）
        thumb_res = upload_image_material(app_id, app_secret, processed[0][0])
        thumb_media_id = thumb_res.get("media_id")
        if not thumb_media_id:
            raise Exception(f"封面上传未返回 media_id: {thumb_res}")
        print(f"封面上传 OK media_id={thumb_media_id}", file=sys.stderr)

        # 正文图：用 full_* 压到 ≤900KB 走 uploadimg（比草稿箱那版清晰）
        content_urls = []   # [(url, md5, pexels_id)]
        uploaded = []       # [(md5, pexels_id)] 台账用
        for i, (fp, h, pid) in enumerate(full_size, 1):
            small = os.path.join(workdir, f"up_{i}.jpg")
            try:
                _shrink_for_upload(fp, small)
                u = upload_content_image(app_id, app_secret, small)
            except Exception as e:
                print(f"  ! 正文图 {i} 上传失败: {e}", file=sys.stderr)
                continue
            content_urls.append((u, h, pid))
            uploaded.append((h, pid))
            print(f"  + 正文图 {i} OK ({os.path.getsize(small)//1024}KB)", file=sys.stderr)
        if not content_urls:
            raise Exception("正文图片全部上传失败")
        print(f"正文图上传 OK {len(content_urls)} 张（uploadimg）", file=sys.stderr)

        # 4. 建草稿：两种模式共用同一批图，只是"要不要正文/要不要链接"不同
        #    news  = 图文消息，正文带可点击的小程序文字链（content 支持 HTML）
        #    newspic = 纯贴图，无正文（content 只支持纯文本，写链接也点不动）
        today_str = datetime.now().strftime("%Y-%m-%d")
        title = f"{topic}·每日图集（{today_str}）"
        if args.mode == "news":
            blocks = [f'<p><img src="{u}" style="width:100%;"/></p>' for u, _, _ in content_urls]
            blocks.append(_draft_content(topic))
            content = '<p><br/></p>'.join(blocks)
            draft_res = create_news_draft(app_id, app_secret, title, content, thumb_media_id)
            print(f"图文消息草稿 OK media_id={draft_res.get('media_id')}（正文{len(content_urls)}图+小程序文字链）", file=sys.stderr)
        else:
            # 贴图：newspic 的 image_list 就是全部贴图，不需要单独的封面
            # （封面 thumb_media_id 是 news 模式才用的）。直接用 full_size 的图，
            # 否则第 1 张（封面素材）和第 2 张（full_1）会是同一张原图的两个压缩版本。
            image_media_ids = []
            for i, (fp, h, pid) in enumerate(full_size, 1):
                small = os.path.join(workdir, f"pic_{i}.jpg")
                try:
                    _shrink_for_upload(fp, small)
                    res = upload_image_material(app_id, app_secret, small)
                    if res.get("media_id"):
                        image_media_ids.append(res["media_id"])
                except Exception as e:
                    print(f"  ! 贴图素材 {i} 上传失败: {e}", file=sys.stderr)
            if len(image_media_ids) < 3:
                raise Exception(f"贴图有效图片不足3张（仅{len(image_media_ids)}张）")
            draft_res = create_newspic_draft(app_id, app_secret, title, image_media_ids)
            print(f"贴图草稿 OK media_id={draft_res.get('media_id')}（{len(image_media_ids)}张，无正文）", file=sys.stderr)
        draft_media_id = draft_res.get("media_id")
        if not draft_media_id:
            raise Exception(f"建草稿失败: {draft_res}")

        # 4b. 采集图片尺寸（用于云数据库记录）
        from PIL import Image as _PILImage
        image_dims = []
        for f, h, pid in processed:
            try:
                with _PILImage.open(f) as im:
                    image_dims.append((im.width, im.height))
            except Exception:
                image_dims.append((0, 0))

        # 4c. 小程序云存储转存：原图(full_*) + 缩略图(final_*) → COS + 数据库
        cloud_records = cloud_stash(save_dir, workdir, topic, title, image_dims)
        if cloud_records:
            print(f"☁ 小程序云转存完成 {len(cloud_records)} 张", file=sys.stderr)
        else:
            print(f"⚠ 小程序云转存全部失败（已忽略，不影响主流程）", file=sys.stderr)

        # 5. 草稿成功后才记录 md5 台账 + 当天话题
        record_sent([{"md5": h, "pexels_id": pid, "topic": topic} for h, pid in uploaded])
        record_topic_day(topic)

        # 6. 追加日志
        os.makedirs(LOG_DIR, exist_ok=True)
        with open(os.path.join(LOG_DIR, "gallery_draft.log"), "a", encoding="utf-8") as f:
            f.write(f"{datetime.now().isoformat()} | {title} | "
                    f"{'正文图' if args.mode == 'news' else '贴图'}{len(content_urls)}张 | "
                    f"草稿media_id={draft_media_id} | type={args.mode}\n")

        # stdout 供 cron 汇报
        full_files = sorted(glob.glob(os.path.join(save_dir, "full_*.jpg")))
        print(json.dumps({
            "status": "success",
            "topic": topic,
            "mode": args.mode,
            "images": len(content_urls),
            "article_type": "news" if args.mode == "news" else "newspic",
            "skipped_dup": skipped,
            "rejected_qc": rejected,
            "title": title,
            "media_id": draft_media_id,
            "thumb_media_id": thumb_media_id,
            "save_dir": save_dir,
            "full_images": [os.path.basename(f) for f in full_files],
            "cloud_records": cloud_records,
        }, ensure_ascii=False, indent=2))
    finally:
        shutil.rmtree(workdir, ignore_errors=True)


# ============================================================
# 小程序云环境：云存储转存 + 数据库记录
# ============================================================

CLOUD_APPID = "wx489060715b335aaf"
CLOUD_SECRET = "fad6d8897931fb0a741209c96fc563a8"
CLOUD_ENV = "cloud1-d9gkyv32i776bf4cc"
CLOUD_TOKEN_CACHE = {"token": None, "expires_at": 0}

# 话题 → 标签映射（一对多，按图集关键词匹配）
TOPIC_TAG_MAP = {
    # 自然景观
    "秋天": ["风景"], "秋叶": ["风景"], "雪景": ["风景"], "星空": ["风景", "星空"],
    "大海": ["风景", "旅行"], "森林": ["风景"], "花朵": ["风景", "植物"],
    "日出": ["风景"], "城市夜景": ["风景", "旅行"], "山川": ["风景"],
    "春天": ["风景", "植物"], "夏日": ["风景", "旅行"], "黄昏": ["风景"],
    "湖泊": ["风景"], "沙漠": ["风景", "旅行"], "极光": ["风景", "星空"],
    "云海": ["风景"], "溪流": ["风景"],
    "梯田": ["风景", "旅行"], "峡谷": ["风景"], "瀑布": ["风景"],
    "湿地": ["风景", "植物"], "草原": ["风景"],
    "秋林小径": ["风景"], "雾凇": ["风景"], "盐湖": ["风景"],
    "火山口": ["风景"], "冰川": ["风景"], "雨林": ["风景", "植物"],
    "荷塘": ["风景", "植物"], "海边落日": ["风景", "旅行"],
    "梯田晨雾": ["风景", "旅行"],
    # 建筑
    "古镇小桥流水": ["建筑", "旅行"], "摩天大楼": ["建筑", "科技"],
    "现代建筑": ["建筑"], "古建筑": ["建筑"], "教堂": ["建筑"],
    "桥梁": ["建筑"], "吊桥": ["建筑"], "灯塔": ["建筑"],
    "风车": ["建筑"], "水乡古镇": ["建筑", "旅行"],
    "城堡": ["建筑"], "高楼窗景": ["建筑"], "街头巷弄": ["建筑"],
    "图书馆": ["建筑"], "车站": ["建筑"], "庭院": ["建筑"],
    "老城区": ["建筑", "旅行"], "玻璃幕墙": ["建筑"],
    "天台视角": ["建筑"], "胡同人家": ["建筑"],
    "石库门": ["建筑"], "徽派民居": ["建筑"],
    "窑洞": ["建筑"], "客家土楼": ["建筑"],
    "栈桥": ["建筑"], "缆车": ["建筑", "旅行"],
    "夜市": ["旅行"], "地下通道": ["建筑"],
    # 世界地标/古迹
    "古迹遗址": ["建筑", "旅行"], "雅典卫城": ["建筑", "旅行"],
    "吴哥窟": ["建筑", "旅行"], "马丘比丘": ["建筑", "旅行"],
    "巨石阵": ["建筑", "旅行"], "帕特农神庙": ["建筑", "旅行"],
    "比萨斜塔": ["建筑", "旅行"], "科隆大教堂": ["建筑"],
    "圣家堂": ["建筑"], "米兰大教堂": ["建筑"],
    "摩索拉斯陵墓": ["建筑"], "长城": ["建筑", "旅行"],
    "故宫": ["建筑", "旅行"], "天坛": ["建筑"],
    "西湖": ["风景", "旅行"], "黄山": ["风景", "旅行"],
    "桂林山水": ["风景", "旅行"], "张家界": ["风景", "旅行"],
    "九寨沟": ["风景", "旅行"], "布达拉宫": ["建筑", "旅行"],
    "兵马俑": ["建筑"], "敦煌莫高窟": ["建筑"],
    "外滩": ["建筑", "旅行"], "东方明珠": ["建筑"],
    "上海陆家嘴": ["建筑"], "广州塔": ["建筑"],
    "云南洱海": ["风景", "旅行"], "稻城亚丁": ["风景", "旅行"],
    "喀纳斯": ["风景", "旅行"], "埃菲尔铁塔": ["建筑", "旅行"],
    "金字塔": ["建筑", "旅行"], "泰姬陵": ["建筑", "旅行"],
    "富士山": ["风景", "旅行"], "圣托里尼": ["风景", "旅行"],
    "威尼斯": ["建筑", "旅行"], "罗马斗兽场": ["建筑"],
    "悉尼歌剧院": ["建筑"], "自由女神": ["建筑"],
    "里约基督像": ["建筑"], "佩特拉古城": ["建筑", "旅行"],
    "黄石公园": ["风景", "旅行"], "大峡谷": ["风景", "旅行"],
    "尼亚加拉瀑布": ["风景", "旅行"], "阿尔卑斯山": ["风景", "旅行"],
    "马尔代夫": ["风景", "旅行"], "巴厘岛": ["风景", "旅行"],
    "布拉格": ["建筑", "旅行"], "阿姆斯特丹": ["建筑", "旅行"],
    "冰岛黑沙滩": ["风景", "旅行"], "挪威峡湾": ["风景", "旅行"],
    "土耳其热气球": ["旅行"], "撒哈拉沙漠": ["风景", "旅行"],
    "日月潭": ["风景", "旅行"], "呼伦贝尔": ["风景", "旅行"],
    "青海湖": ["风景", "旅行"], "泰山": ["风景", "旅行"],
    "华山": ["风景", "旅行"], "峨眉山": ["风景", "旅行"],
    "武当山": ["风景", "旅行"], "平遥古城": ["建筑", "旅行"],
    "凤凰古城": ["建筑", "旅行"], "婺源": ["风景", "旅行"],
    "宏村": ["建筑", "旅行"], "泸沽湖": ["风景", "旅行"],
    "香格里拉": ["风景", "旅行"], "拉萨": ["建筑", "旅行"],
    "香港夜景": ["建筑", "旅行"], "台北101": ["建筑"],
    "新加坡滨海湾": ["建筑", "旅行"], "迪拜塔": ["建筑"],
    "吴哥日出": ["建筑", "旅行"], "雅典神庙": ["建筑", "旅行"],
    # 人文生活
    "阅读": ["人像"], "咖啡馆": ["人像"], "街头摄影师": ["人像"],
    "茶室": ["人像"], "书店": ["建筑"], "集市": ["旅行"],
    "雨天街道": ["旅行"], "夜景人像": ["人像"],
    "帐篷露营": ["旅行"], "滑雪": ["运动", "旅行"],
    "海滩日光浴": ["旅行"], "手艺市集": ["旅行"],
    "街头演出": ["旅行"], "晨跑": ["运动"],
    "垂钓": ["旅行"], "登山者": ["运动", "旅行"],
    "家庭厨房": ["人像"], "街头小吃摊": ["美食", "旅行"],
    "露营篝火": ["旅行"], "陶艺工坊": ["人像"],
    "木工坊": ["人像"],
}


def _get_cloud_token():
    """获取小程序云开发 access_token（带缓存，提前 5 分钟刷新）"""
    now = time.time()
    if CLOUD_TOKEN_CACHE["token"] and now < CLOUD_TOKEN_CACHE["expires_at"] - 300:
        return CLOUD_TOKEN_CACHE["token"]
    r = requests.get(
        "https://api.weixin.qq.com/cgi-bin/token",
        params={"grant_type": "client_credential", "appid": CLOUD_APPID, "secret": CLOUD_SECRET},
        timeout=15,
    )
    data = r.json()
    tok = data.get("access_token")
    if not tok:
        raise Exception(f"云开发 token 获取失败: {data}")
    CLOUD_TOKEN_CACHE["token"] = tok
    CLOUD_TOKEN_CACHE["expires_at"] = now + data.get("expires_in", 7200)
    return tok


def upload_to_cloud(image_path, cloud_path):
    """上传图片到小程序云存储，返回 file_id。

    cloud_path: 云存储路径，如 'images/original/1790320786526-abc123.jpg'
    """
    tok = _get_cloud_token()
    # 1. 获取上传凭证
    r = requests.post(
        f"https://api.weixin.qq.com/tcb/uploadfile?access_token={tok}",
        json={"env": CLOUD_ENV, "path": cloud_path}, timeout=15,
    )
    info = r.json()
    if info.get("errcode") != 0:
        raise Exception(f"云存储获取上传凭证失败: {info}")
    # 2. 上传到 COS
    with open(image_path, "rb") as f:
        files = {
            "key": (None, cloud_path),
            "Signature": (None, info["authorization"]),
            "x-cos-security-token": (None, info["token"]),
            "x-cos-meta-fileid": (None, info["cos_file_id"]),
            "file": (os.path.basename(image_path), f, "image/jpeg"),
        }
        up = requests.post(info["url"], files=files, timeout=60)
    if up.status_code not in (200, 204):
        raise Exception(f"云存储 COS 上传失败: HTTP {up.status_code} {up.text[:200]}")
    return info["file_id"]


def record_image_to_db(title, category, original_file_id, thumbnail_file_id,
                       width, height, tags=None, categories=None):
    """向小程序云数据库 images 集合插入一条图片记录。"""
    if tags is None:
        tags = []
    if categories is None:
        categories = [category] if category else []
    tok = _get_cloud_token()
    now_ms = int(time.time() * 1000)
    parts = [
        "db.collection('images').add({",
        "data: [{",
        "title: " + json.dumps(title, ensure_ascii=False) + ",",
        "category: " + json.dumps(category, ensure_ascii=False) + ",",
        "categories: " + json.dumps(categories, ensure_ascii=False) + ",",
        "tags: " + json.dumps(tags, ensure_ascii=False) + ",",
        "originalFileID: " + json.dumps(original_file_id) + ",",
        "thumbnailFileID: " + json.dumps(thumbnail_file_id) + ",",
        "width: " + str(width) + ",",
        "height: " + str(height) + ",",
        "uploadTime: new Date(" + str(now_ms) + "),",
        "downloads: 0, status: 1, reviewer: '', reviewTime: null",
        "}]})"
    ]
    q = " ".join(parts)
    r = requests.post(
        f"https://api.weixin.qq.com/tcb/databaseadd?access_token={tok}",
        json={"env": CLOUD_ENV, "query": q},
        timeout=15,
    )
    data = r.json()
    if data.get("errcode") != 0:
        raise Exception(f"云数据库写入失败: {data}")
    return data.get("id_list", [None])[0]


def cloud_stash(orig_dir, thumb_dir, topic, title, image_widths_heights, tags=None):
    """把一批处理好的图片转存到小程序云存储 + 写数据库。

    orig_dir: 包含 full_*.jpg（全尺寸/原图）的目录
    thumb_dir: 包含 final_*.jpg（压缩版/缩略图）的目录
    image_widths_heights: 与图片一一对应的 [(width, height), ...]，按 final_1, final_2 顺序
    tags: 标签列表，如不传则从 TOPIC_TAG_MAP 按 topic 自动匹配

    返回: [(original_file_id, thumbnail_file_id, _id), ...]
    """
    if tags is None:
        tags = TOPIC_TAG_MAP.get(topic, [topic])
    category = tags[0] if tags else topic
    categories = tags
    results = []
    ts = int(time.time() * 1000)
    for i, (w, h) in enumerate(image_widths_heights, start=1):
        short = hashlib.md5(f"{ts}-{i}".encode()).hexdigest()[:8]
        orig_path = os.path.join(orig_dir, f"full_{i}.jpg")
        thumb_path = os.path.join(thumb_dir, f"final_{i}.jpg")
        if not os.path.exists(orig_path) or not os.path.exists(thumb_path):
            print(f"  ! 云转存跳过第 {i} 张（文件缺失）", file=sys.stderr)
            continue
        # 原图路径：images/original/
        orig_cloud_path = f"images/original/{ts}-{short}.jpg"
        thumb_cloud_path = f"images/thumbnails/{ts}-{short}.jpg"
        try:
            orig_fid = upload_to_cloud(orig_path, orig_cloud_path)
            thumb_fid = upload_to_cloud(thumb_path, thumb_cloud_path)
            rec_id = record_image_to_db(title, category, orig_fid, thumb_fid, w, h, tags=tags, categories=categories)
            results.append((orig_fid, thumb_fid, rec_id))
            print(f"  ☁ 云转存 OK #{i}: orig={orig_fid} thumb={thumb_fid} db_id={rec_id} tags={tags}", file=sys.stderr)
        except Exception as e:
            print(f"  ! 云转存失败 #{i}: {e}", file=sys.stderr)
    return results


if __name__ == "__main__":
    main()